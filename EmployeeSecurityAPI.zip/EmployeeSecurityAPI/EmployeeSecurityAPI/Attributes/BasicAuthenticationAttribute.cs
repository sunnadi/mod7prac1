using System.Net.Http.Headers;
using System.Security.Claims;
using System.Text;
using EmployeeSecurityAPI.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace EmployeeSecurityAPI.Attributes;

/// <summary>
/// Basic-аутентификация. Проверяет заголовок Authorization: Basic base64(login:password),
/// при успехе создаёт ClaimsPrincipal и записывает его в HttpContext.User.
/// При ошибке возвращает 401 Unauthorized.
/// </summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = false)]
public class BasicAuthenticationAttribute : Attribute, IAuthorizationFilter, IOrderedFilter
{
    // Должен выполняться раньше MyAuthorize (меньший Order — раньше)
    public int Order { get; set; } = 1;

    public void OnAuthorization(AuthorizationFilterContext context)
    {
        // 1. Получаем заголовок Authorization
        if (!context.HttpContext.Request.Headers.TryGetValue("Authorization", out var headerValues))
        {
            Unauthorized(context);
            return;
        }

        try
        {
            // 2. Проверяем схему Basic
            if (!AuthenticationHeaderValue.TryParse(headerValues.ToString(), out var header) ||
                !string.Equals(header.Scheme, "Basic", StringComparison.OrdinalIgnoreCase) ||
                string.IsNullOrWhiteSpace(header.Parameter))
            {
                Unauthorized(context);
                return;
            }

            // 3. Декодируем Base64 (при некорректной строке — FormatException)
            var decoded = Encoding.UTF8.GetString(Convert.FromBase64String(header.Parameter));

            // 4. Делим на логин и пароль (по первому двоеточию — пароль может содержать ':')
            var separatorIndex = decoded.IndexOf(':');
            if (separatorIndex <= 0)
            {
                Unauthorized(context);
                return;
            }

            var userName = decoded[..separatorIndex];
            var password = decoded[(separatorIndex + 1)..];

            // 5. Проверяем учётные данные через UserService
            var userService = context.HttpContext.RequestServices.GetRequiredService<IUserService>();
            var user = userService.ValidateCredentials(userName, password);
            if (user is null)
            {
                Unauthorized(context);
                return;
            }

            // 6. Claims: имя, email, id, роли
            var claims = new List<Claim>
            {
                new(ClaimTypes.Name, user.UserName),
                new(ClaimTypes.Email, user.Email),
                new(ClaimTypes.NameIdentifier, user.Id.ToString())
            };
            claims.AddRange(user.Roles.Select(role => new Claim(ClaimTypes.Role, role)));

            // 7. ClaimsIdentity и ClaimsPrincipal
            var identity = new ClaimsIdentity(claims, "Basic");
            var principal = new ClaimsPrincipal(identity);

            // 8. Текущий пользователь
            context.HttpContext.User = principal;
        }
        catch (FormatException)
        {
            // Некорректная строка Base64
            Unauthorized(context);
        }
        catch (ArgumentException)
        {
            // Некорректные байты / символы
            Unauthorized(context);
        }
    }

    private static void Unauthorized(AuthorizationFilterContext context)
    {
        context.HttpContext.Response.Headers["WWW-Authenticate"] = "Basic realm=\"EmployeeSecurityAPI\", charset=\"UTF-8\"";
        context.Result = new UnauthorizedResult(); // 401
    }
}
