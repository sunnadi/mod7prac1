using EmployeeSecurityAPI.Attributes;
using EmployeeSecurityAPI.Models;
using EmployeeSecurityAPI.Services;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeSecurityAPI.Controllers;

[ApiController]
[Route("api/employees")]
public class EmployeeController : ControllerBase
{
    private readonly IEmployeeService _employees;

    public EmployeeController(IEmployeeService employees)
    {
        _employees = employees;
    }

    // GET /api/employees — Admin, Superadmin
    [HttpGet]
    [BasicAuthentication]
    [MyAuthorize("Admin", "Superadmin")]
    public ActionResult<IEnumerable<Employee>> GetAll() => Ok(_employees.GetAll());

    // GET /api/employees/male — только Admin
    [HttpGet("male")]
    [BasicAuthentication]
    [MyAuthorize("Admin")]
    public ActionResult<IEnumerable<Employee>> GetMale() => Ok(_employees.GetByGender("Male"));

    // GET /api/employees/female — только Superadmin
    [HttpGet("female")]
    [BasicAuthentication]
    [MyAuthorize("Superadmin")]
    public ActionResult<IEnumerable<Employee>> GetFemale() => Ok(_employees.GetByGender("Female"));

    // GET /api/employees/{id} — Admin, Superadmin
    [HttpGet("{id:int}")]
    [BasicAuthentication]
    [MyAuthorize("Admin", "Superadmin")]
    public ActionResult<Employee> GetById(int id)
    {
        var employee = _employees.GetById(id);
        return employee is null ? NotFound() : Ok(employee);
    }

    // GET /api/employees/public — без аутентификации, без персональных данных
    [HttpGet("public")]
    public IActionResult GetPublic()
    {
        var all = _employees.GetAll().ToList();

        return Ok(new
        {
            Company = "Employee Security Co.",
            TotalEmployees = all.Count,
            Departments = all
                .GroupBy(e => e.Department)
                .Select(g => new { Department = g.Key, Employees = g.Count() })
                .OrderBy(d => d.Department)
        });
    }
}
