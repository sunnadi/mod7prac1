using EmployeeSecurityAPI.Models;

namespace EmployeeSecurityAPI.Services;

public interface IUserService
{
    User? ValidateCredentials(string userName, string password);
    IEnumerable<User> GetAll();
}
