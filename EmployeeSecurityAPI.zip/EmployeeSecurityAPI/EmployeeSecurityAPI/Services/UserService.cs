using EmployeeSecurityAPI.Models;

namespace EmployeeSecurityAPI.Services;

public class UserService : IUserService
{
    private readonly List<User> _users = new()
    {
        new User { Id = 1, UserName = "AdminUser",      Password = "Admin123", Email = "admin@company.kz", Roles = new() { "Admin" } },
        new User { Id = 2, UserName = "SuperadminUser", Password = "Super123", Email = "super@company.kz", Roles = new() { "Superadmin" } },
        new User { Id = 3, UserName = "BothUser",       Password = "Both123",  Email = "both@company.kz",  Roles = new() { "Admin", "Superadmin" } }
    };

    public IEnumerable<User> GetAll() => _users;

    public User? ValidateCredentials(string userName, string password)
    {
        return _users.FirstOrDefault(u =>
            string.Equals(u.UserName, userName, StringComparison.OrdinalIgnoreCase) &&
            u.Password == password);
    }
}
